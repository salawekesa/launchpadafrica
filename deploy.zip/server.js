import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { dbService } from './src/lib/db-service.js';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// API Routes
// Health check
app.get('/api/health', async (req, res) => {
  try {
    // Test database connection
    await dbService.getAllStartups();
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      env: process.env.NODE_ENV || 'development',
      database: 'connected'
    });
  } catch (error) {
    console.error('Health check failed:', error);
    res.status(503).json({ 
      status: 'error',
      timestamp: new Date().toISOString(),
      database: 'disconnected',
      error: error.message
    });
  }
});

// Get all startups
app.get('/api/startups', async (req, res) => {
  try {
    const startups = await dbService.getAllStartups();
    res.json(startups);
  } catch (error) {
    console.error('Error fetching startups:', error);
    res.status(500).json({ 
      error: 'Failed to fetch startups',
      message: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Get single startup by ID
app.get('/api/startups/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const startups = await dbService.getAllStartups();
    const startup = startups.find(s => s.id === parseInt(id));
    
    if (!startup) {
      return res.status(404).json({ error: 'Startup not found' });
    }
    
    res.json(startup);
  } catch (error) {
    console.error('Error fetching startup:', error);
    res.status(500).json({ 
      error: 'Failed to fetch startup',
      message: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Add new startup
app.post('/api/startups', async (req, res) => {
  try {
    const startupData = req.body;
    
    // Validate required fields
    if (!startupData.name || !startupData.tagline) {
      return res.status(400).json({ 
        error: 'Missing required fields',
        required: ['name', 'tagline']
      });
    }
    
    console.log('New startup submitted:', startupData.name);
    
    const newStartup = await dbService.createStartup(startupData);
    res.status(201).json(newStartup);
  } catch (error) {
    console.error('Error creating startup:', error);
    res.status(500).json({ 
      error: 'Failed to create startup',
      message: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Get leaderboard
app.get('/api/leaderboard', async (req, res) => {
  try {
    const startups = await dbService.getAllStartups();
    // Sort by growth rate and create leaderboard entries
    const leaderboard = startups
      .sort((a, b) => {
        const aGrowth = parseFloat(a.growth?.replace('%', '') || '0');
        const bGrowth = parseFloat(b.growth?.replace('%', '') || '0');
        return bGrowth - aGrowth;
      })
      .map((startup, index) => ({
        id: index + 1,
        startup_id: startup.id,
        rank: index + 1,
        growth_rate: startup.growth || '+0%',
        startup: startup
      }));
    
    res.json(leaderboard);
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    res.status(500).json({ 
      error: 'Failed to fetch leaderboard',
      message: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Serve static files from dist folder
app.use(express.static(path.join(__dirname, 'dist'), {
  maxAge: '1d',
  etag: true
}));

// Handle React Router - send all other requests to index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully...');
  process.exit(0);
});

// Start server
app.listen(PORT, () => {
  console.log('='.repeat(50));
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔌 API endpoints available at /api/*`);
  console.log(`🌐 CORS enabled for: ${process.env.CORS_ORIGIN || 'all origins'}`);
  console.log('='.repeat(50));
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`❌ Port ${PORT} is already in use`);
  } else {
    console.error('❌ Server error:', err);
  }
  process.exit(1);
});

export default app;

