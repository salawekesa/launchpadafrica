# ⚡ Quick Hostinger cPanel Deployment Checklist

## Before You Start
- [ ] You have Hostinger Business hosting or higher (Node.js support required)
- [ ] You have cPanel access
- [ ] Your build is complete (`npm run build` - ✅ Done!)

---

## 1️⃣ Prepare Your Files (2 minutes)

### Create .env file in project root:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=your_db_name
DB_USER=your_db_user
DB_PASSWORD=your_db_password
PORT=3000
NODE_ENV=production
```

### Files to upload (create a ZIP):
- [x] package.json ✅
- [x] package-lock.json ✅
- [x] server.js ✅
- [x] dist/ folder ✅
- [x] src/ folder ✅
- [ ] .env (create this!)

**Skip**: node_modules, .git, vite.config.ts

---

## 2️⃣ Setup PostgreSQL Database in cPanel (3 minutes)

1. cPanel → **PostgreSQL Databases**
2. Create database (e.g., `username_lift`)
3. Create user with strong password
4. Add user to database → Grant ALL PRIVILEGES
5. **Write down**:
   - Database name: ________________
   - Username: ________________
   - Password: ________________

---

## 3️⃣ Setup Node.js App in cPanel (5 minutes)

1. cPanel → **Setup Node.js App** → **Create Application**

2. Fill settings:
   - **Node.js version**: 18.x or 20.x
   - **Application mode**: Production
   - **Application root**: `public_html` (or your folder)
   - **Application URL**: your domain
   - **Startup file**: `server.js`

3. Add Environment Variables (scroll down):
   ```
   DB_HOST = localhost
   DB_PORT = 5432
   DB_NAME = (your database name)
   DB_USER = (your database user)
   DB_PASSWORD = (your database password)
   NODE_ENV = production
   PORT = 3000
   ```

4. Click **Save**

---

## 4️⃣ Upload Files (5 minutes)

### Option A: ZIP Upload (Easier)
1. Create ZIP of your project files (include .env!)
2. cPanel → **File Manager**
3. Go to `public_html` (or your app folder)
4. Click **Upload** → Select ZIP
5. Right-click ZIP → **Extract**
6. Delete ZIP after extraction

### Option B: FTP
1. Use FileZilla
2. Upload all files to your app directory

---

## 5️⃣ Install & Start (3 minutes)

1. Go back to **Setup Node.js App**
2. Find your application
3. Click **"Run NPM Install"** button
4. Wait 2-5 minutes for completion
5. Click **"Restart"** button

---

## 6️⃣ Initialize Database (2 minutes)

1. cPanel → **Terminal** (or use SSH)
2. Navigate to app:
   ```bash
   cd public_html
   ```
3. Initialize database:
   ```bash
   npm run init-db
   ```

---

## 7️⃣ Test Your Site (2 minutes)

Open these URLs in your browser:

- [ ] **Main site**: `https://yourdomain.com`
  - Should show your app
  
- [ ] **Health check**: `https://yourdomain.com/api/health`
  - Should return: `{"status":"ok"...}`
  
- [ ] **API test**: `https://yourdomain.com/api/startups`
  - Should return data or empty array

---

## ✅ Success Indicators

- ✅ Main site loads with no errors
- ✅ Navigation works (try different pages)
- ✅ API health check returns OK
- ✅ No console errors (F12 → Console)
- ✅ Can submit a startup (test the form)

---

## ❌ If Something's Wrong

### Site won't load?
- Check **Application Log** in Setup Node.js App
- Verify `server.js` is in the root directory
- Make sure you clicked "Restart"

### "package.json required" error?
- Confirm package.json is in your application root
- Check Application root path in Node.js App settings

### Database errors?
- Verify environment variables are correct
- Test: `npm run test-db` in Terminal
- Check database exists in PostgreSQL Databases

### Still stuck?
👉 Read full guide: `HOSTINGER_CPANEL_GUIDE.md`

---

## 🔄 To Update Later

1. Rebuild: `npm run build`
2. Upload new `dist/` folder
3. Setup Node.js App → **Restart**

---

## 📞 Need Help?

- Full deployment guide: `HOSTINGER_CPANEL_GUIDE.md`
- Hostinger Support: https://www.hostinger.com/tutorials
- Check application logs in Setup Node.js App

---

**Total Time**: ~20 minutes
**Difficulty**: Medium

Good luck! 🚀

